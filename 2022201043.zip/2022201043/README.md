Q1
In question 1, I have taken command line argument, so the path needs to entered while executing the file.
Before executing the file we have to change the mode using chmod +x q1.sh
This q1.sh file  is a bash script that is supposed to take path from the user and then visit that text file and prints the middle line of the file.

Q2
Before executing the file we have to change the mode using chmod +x q2.sh
Thus is a bash script that prints out names of all the shells that belongs to '/usr/'
